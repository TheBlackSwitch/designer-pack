execute unless function theblackswitch:v2.0/patch-5/version_control/is_latest run return fail
$tp @s ~$(x) ~$(y) ~$(z) ~$(yaw) ~$(pitch)
