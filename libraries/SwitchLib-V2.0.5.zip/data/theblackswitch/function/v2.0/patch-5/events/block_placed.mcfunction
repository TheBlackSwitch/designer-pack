execute unless function theblackswitch:v2.0/patch-5/version_control/is_latest run return fail
advancement revoke @s only theblackswitch:v2.0/patch-5/block_placed
execute at @s run function #theblackswitch:v2.0/events/block_placed
